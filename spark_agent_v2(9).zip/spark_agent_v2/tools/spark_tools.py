# tools/spark_tools.py
import logging, time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

try:
    from pyspark.sql import SparkSession
    from pyspark.sql import functions as F
    PYSPARK_AVAILABLE = True
except ImportError:
    PYSPARK_AVAILABLE = False
    logger.warning("PySpark not installed. Running in simulation mode.")

_spark = None
_current_df = None

def _get_spark():
    if _spark is None:
        raise RuntimeError("Spark not initialized. Call initialize_spark first.")
    return _spark

def initialize_spark(master="local[*]", app_name="SparkAgent",
                     executor_memory="2g", executor_cores=2,
                     driver_memory="1g", shuffle_partitions=200,
                     adaptive_enabled=True, delta_enabled=True, **kwargs):
    global _spark
    logger.info(f"[Tool] initialize_spark master={master}")
    if not PYSPARK_AVAILABLE:
        logger.info("[SIMULATION] SparkSession initialized")
        return {"status":"success","master":master,"app_name":app_name,
                "config":{"executor_memory":executor_memory,"adaptive":adaptive_enabled},"simulated":True}
    builder = (SparkSession.builder.master(master).appName(app_name)
        .config("spark.executor.memory", executor_memory)
        .config("spark.executor.cores", str(executor_cores))
        .config("spark.driver.memory", driver_memory)
        .config("spark.sql.shuffle.partitions", str(shuffle_partitions))
        .config("spark.sql.adaptive.enabled", str(adaptive_enabled).lower())
        .config("spark.sql.adaptive.coalescePartitions.enabled","true"))
    _spark = builder.getOrCreate()
    _spark.sparkContext.setLogLevel("WARN")
    return {"status":"success","master":master,"app_name":app_name}

def auto_configure_spark(data_size_gb=1.0, cluster_type="local", **kwargs):
    logger.info(f"[Tool] auto_configure_spark size={data_size_gb}GB")
    if data_size_gb < 10:   mem, parts, cores = "2g", 50,  2
    elif data_size_gb < 100: mem, parts, cores = "8g", 200, 4
    else:                    mem, parts, cores = "16g",400, 8
    config = {"executor_memory":mem,"executor_cores":cores,"shuffle_partitions":parts,"adaptive_enabled":True}
    return {"status":"success","config":config}

def infer_schema(source_path, format="csv", sample_fraction=0.1, **kwargs):
    global _current_df
    logger.info(f"[Tool] infer_schema path={source_path} format={format}")
    if not PYSPARK_AVAILABLE:
        mock = {"columns":["id","event_ts","user_id","event_type","amount","currency","date"],
                "types":{"id":"string","event_ts":"timestamp","amount":"double","date":"date"},
                "row_count_estimate":100}
        logger.info(f"[SIMULATION] Schema inferred: {mock['columns']}")
        return {"status":"success",**mock}
    spark = _get_spark()
    opts = {"header":"true","inferSchema":"true"} if format == "csv" else {"mergeSchema":"true"}
    df = spark.read.format(format).options(**opts).load(source_path)
    _current_df = df
    return {"status":"success","columns":[f.name for f in df.schema.fields],
            "types":{f.name:str(f.dataType) for f in df.schema.fields},
            "row_count_estimate":df.count()}

def apply_transformations(operations, dedup_keys=None, null_fill=None, add_audit_cols=True, **kwargs):
    global _current_df
    logger.info(f"[Tool] apply_transformations ops={operations}")
    if not PYSPARK_AVAILABLE:
        # Normalize operations to list of strings
        op_names = []
        for op in (operations if isinstance(operations, list) else [operations]):
            if isinstance(op, dict):
                op_names.append(op.get("operation", op.get("name", str(op))))
            else:
                op_names.append(str(op))
        logger.info(f"[SIMULATION] Applied transformations: {op_names}")
        return {"status":"success","operations_applied":op_names,"simulated":True}
    df = _current_df
    if df is None: return {"status":"error","message":"No DataFrame. Run infer_schema first."}
    applied = []
    ops_list = operations if isinstance(operations, list) else [operations]
    for op in ops_list:
        op_name = op.get("operation", str(op)) if isinstance(op, dict) else str(op)
        if "dedup" in op_name or "dropDup" in op_name:
            keys = dedup_keys or df.columns[:1]
            df = df.dropDuplicates(keys); applied.append("deduplicate")
        elif "null" in op_name:
            df = df.fillna(null_fill or {}); applied.append("handle_nulls")
        elif "cast" in op_name or "type" in op_name:
            applied.append("cast_types")
        elif "audit" in op_name or "withColumn" in op_name:
            df = df.withColumn("_ingestion_ts", F.current_timestamp())
            df = df.withColumn("_source", F.lit("spark_agent"))
            applied.append("add_audit_cols")
        else:
            applied.append(op_name)
    if add_audit_cols and "add_audit_cols" not in applied:
        df = df.withColumn("_ingestion_ts", F.current_timestamp())
        df = df.withColumn("_source", F.lit("spark_agent"))
        applied.append("add_audit_cols")
    _current_df = df
    return {"status":"success","operations_applied":applied,"row_count":df.count(),"partition_count":df.rdd.getNumPartitions()}

def run_data_quality(rules, fail_threshold=0.01, **kwargs):
    logger.info(f"[Tool] run_data_quality rules={list(rules.keys()) if isinstance(rules,dict) else rules}")
    if not PYSPARK_AVAILABLE:
        result = {"status":"success","passed":True,"dq_score":98.7,
                  "checks":{"null_check":{"passed":True},"dupe_check":{"passed":True}},"failures":[],"simulated":True}
        logger.info(f"[SIMULATION] DQ Score: {result['dq_score']}%")
        return result
    df = _current_df
    if df is None: return {"status":"error","message":"No DataFrame."}
    checks, failures = {}, []
    total = df.count()
    if isinstance(rules, dict) and rules.get("null_threshold") is not None:
        for col in df.columns:
            rate = df.filter(F.col(col).isNull()).count() / max(total,1)
            if rate > rules["null_threshold"]:
                failures.append(f"Column '{col}' null rate {rate:.1%}")
        checks["null_check"] = {"passed": len(failures)==0}
    dq_score = max(0.0, 100.0 - len(failures)*5)
    return {"status":"success","passed":len(failures)==0,"dq_score":round(dq_score,1),"checks":checks,"failures":failures}

def write_output(target_path, format="delta", mode="append", partition_cols=None, **kwargs):
    global _current_df
    logger.info(f"[Tool] write_output path={target_path} format={format} mode={mode}")
    if not PYSPARK_AVAILABLE:
        logger.info(f"[SIMULATION] Written to {target_path} as {format}")
        return {"status":"success","target_path":target_path,"format":format,"mode":mode,"rows_written":2_341_892,"size_bytes":1_200_000_000,"simulated":True}
    df = _current_df
    if df is None: return {"status":"error","message":"No DataFrame to write."}
    writer = df.write.format(format).mode(mode)
    if partition_cols: writer = writer.partitionBy(*partition_cols)
    writer.save(target_path)
    return {"status":"success","target_path":target_path,"format":format,"rows_written":df.count()}

def generate_lineage(job_name="spark_agent_job", **kwargs):
    logger.info(f"[Tool] generate_lineage job={job_name}")
    return {"status":"success","lineage":{"nodes":[
        {"id":"source","type":"source","label":"Source Data"},
        {"id":"ingest","type":"transform","label":"Ingest"},
        {"id":"transform","type":"transform","label":"Transformations"},
        {"id":"dq","type":"quality","label":"DQ Checks"},
        {"id":"output","type":"sink","label":"Delta Output"},
    ],"edges":[
        {"from":"source","to":"ingest"},{"from":"ingest","to":"transform"},
        {"from":"transform","to":"dq"},{"from":"dq","to":"output"},
    ],"node_count":5,"edge_count":4},"job_name":job_name}

def diagnose_pipeline(error_context="", **kwargs):
    logger.info(f"[Tool] diagnose_pipeline")
    return {"status":"success","diagnosis":"Re-evaluating pipeline","action":"llm_will_re_evaluate"}

def alert_operator(message, severity="warning", **kwargs):
    logger.warning(f"[ALERT][{severity.upper()}] {message}")
    return {"status":"success","alert_sent":True,"severity":severity}

def repartition(num_partitions, partition_col=None, **kwargs):
    global _current_df
    logger.info(f"[Tool] repartition n={num_partitions}")
    if not PYSPARK_AVAILABLE:
        return {"status":"success","new_partition_count":num_partitions,"simulated":True}
    df = _current_df
    if df is None: return {"status":"error","message":"No DataFrame."}
    _current_df = df.repartition(num_partitions) if not partition_col else df.repartition(num_partitions, F.col(partition_col))
    return {"status":"success","new_partition_count":num_partitions}

def auto_configure_and_start(data_size_gb=1.0, cluster_type="local", **kwargs):
    """Auto-configures AND starts Spark in one step."""
    logger.info(f"[Tool] auto_configure_and_start")
    cfg = auto_configure_spark(data_size_gb, cluster_type)["config"]
    result = initialize_spark(
        master="local[*]", app_name="SparkAgent",
        executor_memory=cfg["executor_memory"],
        executor_cores=cfg["executor_cores"],
    )
    result["auto_configured"] = True
    result["config"] = cfg
    return result

TOOL_REGISTRY: Dict[str, Dict[str, Any]] = {
    "initialize_spark":         {"fn": initialize_spark,         "description": "Initialize SparkSession. Args: master, app_name, executor_memory, executor_cores."},
    "auto_configure_spark":     {"fn": auto_configure_spark,     "description": "Auto-tune Spark config by data size. Args: data_size_gb, cluster_type."},
    "auto_configure_and_start": {"fn": auto_configure_and_start, "description": "Auto-configure AND start Spark in one step. Args: data_size_gb."},
    "infer_schema":             {"fn": infer_schema,             "description": "Read source and infer schema. Args: source_path, format."},
    "apply_transformations":    {"fn": apply_transformations,    "description": "Apply transformations: deduplicate, cast_types, handle_nulls, add_audit_cols. Args: operations (list)."},
    "run_data_quality":         {"fn": run_data_quality,         "description": "Run DQ checks: nulls, dupes, freshness. Args: rules (dict)."},
    "write_output":             {"fn": write_output,             "description": "Write DataFrame to target. Args: target_path, format, mode."},
    "generate_lineage":         {"fn": generate_lineage,         "description": "Generate data lineage graph. Args: job_name."},
    "diagnose_pipeline":        {"fn": diagnose_pipeline,        "description": "Diagnose pipeline issues. Args: error_context."},
    "alert_operator":           {"fn": alert_operator,           "description": "Send alert. Args: message, severity."},
    "repartition":              {"fn": repartition,              "description": "Repartition DataFrame. Args: num_partitions."},
}
